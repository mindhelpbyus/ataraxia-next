export declare const generateToken: (user_id: number, email: string, role: string) => string;
//# sourceMappingURL=jwtGenerator.d.ts.map