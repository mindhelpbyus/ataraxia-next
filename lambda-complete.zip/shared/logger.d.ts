/**
 * Enhanced Logging System
 * Provides structured logging with correlation IDs
 */
export interface LogContext {
    requestId?: string;
    userId?: string | number;
    operation?: string;
    [key: string]: any;
}
export declare class Logger {
    private serviceName;
    constructor(serviceName: string);
    private formatLog;
    info(message: string, context?: LogContext): void;
    warn(message: string, context?: LogContext): void;
    error(message: string, context?: LogContext, error?: Error): void;
    debug(message: string, context?: LogContext): void;
}
export declare function createLogger(serviceName: string): Logger;
/**
 * Performance Monitor
 * Tracks execution time and logs performance metrics
 */
export declare class PerformanceMonitor {
    private startTime;
    private logger;
    private operation;
    private context;
    constructor(logger: Logger, operation: string, context?: LogContext);
    end(success?: boolean, additionalContext?: LogContext): void;
}
//# sourceMappingURL=logger.d.ts.map