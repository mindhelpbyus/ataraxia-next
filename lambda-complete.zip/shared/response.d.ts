/**
 * API Response Utilities
 * Ensures consistent response format with your frontend
 */
import { APIGatewayProxyResult } from 'aws-lambda';
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    message?: string;
    error?: string;
    errors?: any[];
    requestId?: string;
}
export declare function createResponse<T>(statusCode: number, body: ApiResponse<T>, headers?: Record<string, string>): APIGatewayProxyResult;
export declare function successResponse<T>(data: T, message?: string, requestId?: string): APIGatewayProxyResult;
export declare function errorResponse(statusCode: number, error: string, requestId?: string, errors?: any[]): APIGatewayProxyResult;
export declare function validationErrorResponse(errors: any[], requestId?: string): APIGatewayProxyResult;
//# sourceMappingURL=response.d.ts.map