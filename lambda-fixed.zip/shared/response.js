"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createResponse = createResponse;
exports.successResponse = successResponse;
exports.errorResponse = errorResponse;
exports.validationErrorResponse = validationErrorResponse;
function createResponse(statusCode, body, headers = {}) {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': process.env.FRONTEND_URL || 'http://localhost:3000',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
            ...headers
        },
        body: JSON.stringify(body)
    };
}
function successResponse(data, message, requestId) {
    return createResponse(200, {
        success: true,
        data,
        message,
        requestId
    });
}
function errorResponse(statusCode, error, requestId, errors) {
    return createResponse(statusCode, {
        success: false,
        error,
        errors,
        requestId
    });
}
function validationErrorResponse(errors, requestId) {
    return createResponse(400, {
        success: false,
        error: 'Validation failed',
        errors,
        requestId
    });
}
//# sourceMappingURL=response.js.map