"use strict";
/**
 * Enhanced Logging System
 * Provides structured logging with correlation IDs
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceMonitor = exports.Logger = void 0;
exports.createLogger = createLogger;
class Logger {
    constructor(serviceName) {
        this.serviceName = serviceName;
    }
    formatLog(level, message, context, error) {
        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp,
            level,
            service: this.serviceName,
            message,
            ...context,
            ...(error && {
                error: {
                    name: error.name,
                    message: error.message,
                    stack: error.stack
                }
            })
        };
        return JSON.stringify(logEntry);
    }
    info(message, context) {
        console.log(this.formatLog('INFO', message, context));
    }
    warn(message, context) {
        console.warn(this.formatLog('WARN', message, context));
    }
    error(message, context, error) {
        console.error(this.formatLog('ERROR', message, context, error));
    }
    debug(message, context) {
        if (process.env.LOG_LEVEL === 'debug') {
            console.debug(this.formatLog('DEBUG', message, context));
        }
    }
}
exports.Logger = Logger;
function createLogger(serviceName) {
    return new Logger(serviceName);
}
/**
 * Performance Monitor
 * Tracks execution time and logs performance metrics
 */
class PerformanceMonitor {
    constructor(logger, operation, context = {}) {
        this.startTime = Date.now();
        this.logger = logger;
        this.operation = operation;
        this.context = context;
    }
    end(success = true, additionalContext) {
        const duration = Date.now() - this.startTime;
        const finalContext = {
            ...this.context,
            ...additionalContext,
            operation: this.operation,
            duration,
            success
        };
        if (success) {
            this.logger.info(`Operation completed: ${this.operation}`, finalContext);
        }
        else {
            this.logger.error(`Operation failed: ${this.operation}`, finalContext);
        }
        // Log slow operations
        if (duration > 1000) {
            this.logger.warn(`Slow operation detected: ${this.operation}`, finalContext);
        }
    }
}
exports.PerformanceMonitor = PerformanceMonitor;
//# sourceMappingURL=logger.js.map