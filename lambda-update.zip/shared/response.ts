/**
 * API Response Utilities
 * Ensures consistent response format with your frontend
 */
import { APIGatewayProxyResult } from 'aws-lambda';

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  errors?: any[];
  requestId?: string;
}

export function createResponse<T>(
  statusCode: number,
  body: ApiResponse<T>,
  headers: Record<string, string> = {}
): APIGatewayProxyResult {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': process.env.FRONTEND_URL || 'http://localhost:3000',
      'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
      ...headers
    },
    body: JSON.stringify(body)
  };
}

export function successResponse<T>(
  data: T,
  message?: string,
  requestId?: string
): APIGatewayProxyResult {
  return createResponse(200, {
    success: true,
    data,
    message,
    requestId
  });
}

export function errorResponse(
  statusCode: number,
  error: string,
  requestId?: string,
  errors?: any[]
): APIGatewayProxyResult {
  return createResponse(statusCode, {
    success: false,
    error,
    errors,
    requestId
  });
}

export function validationErrorResponse(
  errors: any[],
  requestId?: string
): APIGatewayProxyResult {
  return createResponse(400, {
    success: false,
    error: 'Validation failed',
    errors,
    requestId
  });
}