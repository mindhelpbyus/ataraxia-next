/**
 * Enhanced Logging System
 * Provides structured logging with correlation IDs
 */

export interface LogContext {
  requestId?: string;
  userId?: string | number;
  operation?: string;
  [key: string]: any;
}

export class Logger {
  private serviceName: string;

  constructor(serviceName: string) {
    this.serviceName = serviceName;
  }

  private formatLog(level: string, message: string, context?: LogContext, error?: Error) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      service: this.serviceName,
      message,
      ...context,
      ...(error && {
        error: {
          name: error.name,
          message: error.message,
          stack: error.stack
        }
      })
    };

    return JSON.stringify(logEntry);
  }

  info(message: string, context?: LogContext) {
    console.log(this.formatLog('INFO', message, context));
  }

  warn(message: string, context?: LogContext) {
    console.warn(this.formatLog('WARN', message, context));
  }

  error(message: string, context?: LogContext, error?: Error) {
    console.error(this.formatLog('ERROR', message, context, error));
  }

  debug(message: string, context?: LogContext) {
    if (process.env.LOG_LEVEL === 'debug') {
      console.debug(this.formatLog('DEBUG', message, context));
    }
  }
}

export function createLogger(serviceName: string): Logger {
  return new Logger(serviceName);
}

/**
 * Performance Monitor
 * Tracks execution time and logs performance metrics
 */
export class PerformanceMonitor {
  private startTime: number;
  private logger: Logger;
  private operation: string;
  private context: LogContext;

  constructor(logger: Logger, operation: string, context: LogContext = {}) {
    this.startTime = Date.now();
    this.logger = logger;
    this.operation = operation;
    this.context = context;
  }

  end(success: boolean = true, additionalContext?: LogContext) {
    const duration = Date.now() - this.startTime;
    const finalContext = {
      ...this.context,
      ...additionalContext,
      operation: this.operation,
      duration,
      success
    };

    if (success) {
      this.logger.info(`Operation completed: ${this.operation}`, finalContext);
    } else {
      this.logger.error(`Operation failed: ${this.operation}`, finalContext);
    }

    // Log slow operations
    if (duration > 1000) {
      this.logger.warn(`Slow operation detected: ${this.operation}`, finalContext);
    }
  }
}