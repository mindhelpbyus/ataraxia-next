/**
 * Firebase Admin SDK - Exact same logic as your Express version
 * Maintains compatibility with your existing Firebase setup
 */
import admin from 'firebase-admin';

// Initialize Firebase Admin SDK
// Same logic as your Express version
if (!admin.apps.length) {
    try {
        // Try to use service account file path from environment
        const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;
        
        if (serviceAccountPath) {
            const serviceAccount = require(serviceAccountPath);
            admin.initializeApp({
                credential: admin.credential.cert(serviceAccount)
            });
        } else {
            // Fallback to application default credentials
            admin.initializeApp({
                credential: admin.credential.applicationDefault()
            });
        }
    } catch (error) {
        console.error('Firebase initialization error:', error);
        // Initialize with minimal config for development
        admin.initializeApp();
    }
}

export const verifyFirebaseToken = async (idToken: string) => {
    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        return decodedToken;
    } catch (error: any) {
        console.error('Firebase Admin Verification Error:', error);
        if (error.code === 'app/invalid-credential') {
            console.error('CRITICAL: Firebase Admin SDK credentials are missing or invalid.');
            console.error('Ensure FIREBASE_SERVICE_ACCOUNT_PATH is set or service account is provided.');
        }
        throw new Error(`Invalid Firebase Token: ${error.message}`);
    }
};