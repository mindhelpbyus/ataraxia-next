"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyFirebaseToken = void 0;
/**
 * Firebase Admin SDK - Exact same logic as your Express version
 * Maintains compatibility with your existing Firebase setup
 */
const firebase_admin_1 = __importDefault(require("firebase-admin"));
// Initialize Firebase Admin SDK
// Same logic as your Express version
if (!firebase_admin_1.default.apps.length) {
    try {
        // Try to use service account file path from environment
        const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;
        if (serviceAccountPath) {
            const serviceAccount = require(serviceAccountPath);
            firebase_admin_1.default.initializeApp({
                credential: firebase_admin_1.default.credential.cert(serviceAccount)
            });
        }
        else {
            // Fallback to application default credentials
            firebase_admin_1.default.initializeApp({
                credential: firebase_admin_1.default.credential.applicationDefault()
            });
        }
    }
    catch (error) {
        console.error('Firebase initialization error:', error);
        // Initialize with minimal config for development
        firebase_admin_1.default.initializeApp();
    }
}
const verifyFirebaseToken = async (idToken) => {
    try {
        const decodedToken = await firebase_admin_1.default.auth().verifyIdToken(idToken);
        return decodedToken;
    }
    catch (error) {
        console.error('Firebase Admin Verification Error:', error);
        if (error.code === 'app/invalid-credential') {
            console.error('CRITICAL: Firebase Admin SDK credentials are missing or invalid.');
            console.error('Ensure FIREBASE_SERVICE_ACCOUNT_PATH is set or service account is provided.');
        }
        throw new Error(`Invalid Firebase Token: ${error.message}`);
    }
};
exports.verifyFirebaseToken = verifyFirebaseToken;
//# sourceMappingURL=firebase.js.map