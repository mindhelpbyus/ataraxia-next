/**
 * Auth Lambda Handler - AWS Cognito Version
 * Healthcare-focused authentication without social media complexity
 * Maintains exact same API contract for frontend compatibility
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=handler.d.ts.map