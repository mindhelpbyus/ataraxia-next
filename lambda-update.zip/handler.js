"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const prisma_1 = require("../../lib/prisma");
const logger_1 = require("../../shared/logger");
const response_1 = require("../../shared/response");
const jwtGenerator_js_1 = require("./utils/jwtGenerator.js");
const cognito_1 = require("./utils/cognito");
const logger = (0, logger_1.createLogger)('auth-service');
const prisma = (0, prisma_1.getPrisma)();
const handler = async (event) => {
    const requestId = event.requestContext.requestId;
    const path = event.path;
    const method = event.httpMethod;
    const logContext = {
        requestId,
        path,
        method,
        userAgent: event.headers['User-Agent'],
        ip: event.requestContext.identity.sourceIp
    };
    logger.info('Auth request received', logContext);
    try {
        // Handle CORS preflight
        if (method === 'OPTIONS') {
            return (0, response_1.successResponse)({}, 'CORS preflight', requestId);
        }
        // Route to appropriate handler
        if (path === '/api/auth/register' && method === 'POST') {
            return await handleRegister(event, requestId, logContext);
        }
        if (path === '/api/auth/login' && method === 'POST') {
            return await handleLogin(event, requestId, logContext);
        }
        if (path === '/api/auth/confirm' && method === 'POST') {
            return await handleConfirmSignUp(event, requestId, logContext);
        }
        if (path === '/api/auth/resend-code' && method === 'POST') {
            return await handleResendCode(event, requestId, logContext);
        }
        if (path === '/api/auth/forgot-password' && method === 'POST') {
            return await handleForgotPassword(event, requestId, logContext);
        }
        if (path === '/api/auth/reset-password' && method === 'POST') {
            return await handleResetPassword(event, requestId, logContext);
        }
        if (path.startsWith('/api/auth/therapist/status/') && method === 'GET') {
            const uid = path.split('/').pop();
            return await handleTherapistStatus(uid, requestId, logContext);
        }
        return (0, response_1.errorResponse)(404, 'Route not found', requestId);
    }
    catch (error) {
        logger.error('Unhandled error in auth handler', logContext, error);
        return (0, response_1.errorResponse)(500, 'Internal server error', requestId);
    }
};
exports.handler = handler;
/**
 * Register User - Cognito + Database Integration
 * Professional healthcare registration workflow
 */
async function handleRegister(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'register_user', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, password, first_name, last_name, role, organization_id, phone_number } = body;
        // Validation
        if (!email || !password || !first_name || !last_name) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' },
                { field: 'password', message: 'Password is required' },
                { field: 'first_name', message: 'First name is required' },
                { field: 'last_name', message: 'Last name is required' }
            ], requestId);
        }
        // 1. Check if user exists in our database
        const existingUser = await prisma.users.findFirst({
            where: {
                OR: [
                    { email },
                    ...(phone_number ? [{ phone_number }] : [])
                ]
            }
        });
        if (existingUser) {
            monitor.end(false);
            return (0, response_1.errorResponse)(409, 'User already exists', requestId);
        }
        // 2. Register with Cognito (handles password validation)
        const cognitoResult = await (0, cognito_1.registerUser)(email, password, first_name, last_name, role || 'client', phone_number);
        // 3. Create user in our database with Cognito sub
        let accountStatus = 'active';
        let verificationStage = null;
        if (role === 'therapist') {
            accountStatus = 'onboarding_pending';
            verificationStage = 'account_created';
        }
        const newUser = await prisma.users.create({
            data: {
                email,
                auth_provider_id: cognitoResult.userSub,
                auth_provider_type: 'cognito',
                auth_provider_metadata: {
                    created_via: 'registration',
                    cognito_sub: cognitoResult.userSub,
                    registration_date: new Date().toISOString()
                },
                firebase_uid: cognitoResult.userSub, // Legacy compatibility
                first_name,
                last_name,
                role: role || 'client',
                organization_id: organization_id ? BigInt(organization_id) : null,
                phone_number,
                account_status: accountStatus,
                verification_stage: verificationStage,
                is_active: accountStatus === 'active',
                signup_source: 'email_password',
                signup_platform: 'web',
                auth_methods: ['cognito'],
                email_verified: !cognitoResult.needsVerification
            },
            select: {
                id: true,
                email: true,
                first_name: true,
                last_name: true,
                role: true,
                account_status: true,
                auth_provider_id: true,
                auth_provider_type: true
            }
        });
        monitor.end(true, { userId: Number(newUser.id), cognitoSub: cognitoResult.userSub });
        // Return response indicating if email verification is needed
        return (0, response_1.successResponse)({
            user: {
                ...newUser,
                id: Number(newUser.id)
            },
            needsVerification: cognitoResult.needsVerification,
            message: cognitoResult.needsVerification
                ? 'Please check your email for verification code'
                : 'Registration successful'
        }, 'User registered successfully', requestId);
    }
    catch (error) {
        logger.error('Registration error', logContext, error);
        monitor.end(false);
        if (error.message.includes('already exists')) {
            return (0, response_1.errorResponse)(409, 'User already exists', requestId);
        }
        if (error.message.includes('password')) {
            return (0, response_1.errorResponse)(400, error.message, requestId);
        }
        return (0, response_1.errorResponse)(500, 'Registration failed', requestId);
    }
}
/**
 * Login User - Cognito Authentication
 * Professional healthcare login workflow
 */
async function handleLogin(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'login_user', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, password } = body;
        if (!email || !password) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' },
                { field: 'password', message: 'Password is required' }
            ], requestId);
        }
        // 1. Authenticate with Cognito
        const cognitoResult = await (0, cognito_1.authenticateUser)(email, password);
        // 2. Get user from our database using Cognito sub
        let user = await prisma.users.findFirst({
            where: {
                auth_provider_id: cognitoResult.user.sub,
                auth_provider_type: 'cognito'
            }
        });
        // 3. If user not found by Cognito sub, try by email (migration case)
        if (!user) {
            user = await prisma.users.findUnique({
                where: { email }
            });
            // Update user with Cognito sub for future logins
            if (user) {
                await prisma.users.update({
                    where: { id: user.id },
                    data: {
                        auth_provider_id: cognitoResult.user.sub,
                        auth_provider_type: 'cognito',
                        auth_provider_metadata: {
                            migrated_from: user.firebase_uid ? 'firebase' : 'email_only',
                            migration_date: new Date().toISOString(),
                            cognito_sub: cognitoResult.user.sub
                        },
                        firebase_uid: cognitoResult.user.sub // Legacy compatibility
                    }
                });
            }
        }
        if (!user) {
            monitor.end(false);
            return (0, response_1.errorResponse)(401, 'User not found in system', requestId);
        }
        // 4. Generate our internal JWT token (for compatibility)
        const token = (0, jwtGenerator_js_1.generateToken)(Number(user.id), user.email, user.role);
        // 5. Update last_login_at (async)
        prisma.users.update({
            where: { id: user.id },
            data: { last_login_at: new Date() }
        }).catch(err => logger.error('Failed to update last login', logContext, err));
        monitor.end(true, { userId: Number(user.id) });
        // Same response format as before for frontend compatibility
        return (0, response_1.successResponse)({
            token, // Our internal JWT
            cognitoTokens: {
                accessToken: cognitoResult.accessToken,
                idToken: cognitoResult.idToken,
                refreshToken: cognitoResult.refreshToken
            },
            user: {
                id: Number(user.id),
                email: user.email,
                first_name: user.first_name,
                last_name: user.last_name,
                role: user.role,
                organization_id: user.organization_id ? Number(user.organization_id) : null,
                account_status: user.account_status || 'active',
                verification_stage: user.verification_stage,
                is_active: user.is_active,
                onboardingStatus: user.account_status || 'active' // Frontend compatibility
            }
        }, 'Login successful', requestId);
    }
    catch (error) {
        logger.error('Login error', logContext, error);
        monitor.end(false);
        if (error.message.includes('Invalid email or password')) {
            return (0, response_1.errorResponse)(401, 'Invalid email or password', requestId);
        }
        if (error.message.includes('verify your email')) {
            return (0, response_1.errorResponse)(401, 'Please verify your email address', requestId);
        }
        return (0, response_1.errorResponse)(500, 'Login failed', requestId);
    }
}
/**
 * Confirm Email Verification - Cognito
 * Required after registration for email verification
 */
async function handleConfirmSignUp(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'confirm_signup', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, confirmationCode } = body;
        if (!email || !confirmationCode) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' },
                { field: 'confirmationCode', message: 'Confirmation code is required' }
            ], requestId);
        }
        // Confirm with Cognito
        await (0, cognito_1.confirmSignUp)(email, confirmationCode);
        // Update user in our database
        await prisma.users.update({
            where: { email },
            data: {
                email_verified: true,
                is_active: true
            }
        });
        monitor.end(true);
        return (0, response_1.successResponse)({
            verified: true
        }, 'Email verified successfully', requestId);
    }
    catch (error) {
        logger.error('Email confirmation error', logContext, error);
        monitor.end(false);
        return (0, response_1.errorResponse)(400, error.message, requestId);
    }
}
/**
 * Resend Confirmation Code - Cognito
 */
async function handleResendCode(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'resend_code', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email } = body;
        if (!email) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' }
            ], requestId);
        }
        await (0, cognito_1.resendConfirmationCode)(email);
        monitor.end(true);
        return (0, response_1.successResponse)({
            sent: true
        }, 'Confirmation code sent', requestId);
    }
    catch (error) {
        logger.error('Resend code error', logContext, error);
        monitor.end(false);
        return (0, response_1.errorResponse)(400, error.message, requestId);
    }
}
/**
 * Forgot Password - Cognito
 */
async function handleForgotPassword(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'forgot_password', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email } = body;
        if (!email) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' }
            ], requestId);
        }
        await (0, cognito_1.forgotPassword)(email);
        monitor.end(true);
        return (0, response_1.successResponse)({
            sent: true
        }, 'Password reset code sent to your email', requestId);
    }
    catch (error) {
        logger.error('Forgot password error', logContext, error);
        monitor.end(false);
        return (0, response_1.errorResponse)(400, error.message, requestId);
    }
}
/**
 * Reset Password - Cognito
 */
async function handleResetPassword(event, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'reset_password', logContext);
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, confirmationCode, newPassword } = body;
        if (!email || !confirmationCode || !newPassword) {
            monitor.end(false);
            return (0, response_1.validationErrorResponse)([
                { field: 'email', message: 'Email is required' },
                { field: 'confirmationCode', message: 'Confirmation code is required' },
                { field: 'newPassword', message: 'New password is required' }
            ], requestId);
        }
        await (0, cognito_1.confirmForgotPassword)(email, confirmationCode, newPassword);
        monitor.end(true);
        return (0, response_1.successResponse)({
            reset: true
        }, 'Password reset successfully', requestId);
    }
    catch (error) {
        logger.error('Reset password error', logContext, error);
        monitor.end(false);
        return (0, response_1.errorResponse)(400, error.message, requestId);
    }
}
/**
 * Get Therapist Status - Updated for Cognito
 */
async function handleTherapistStatus(cognitoSub, requestId, logContext) {
    const monitor = new logger_1.PerformanceMonitor(logger, 'get_therapist_status', { ...logContext, cognitoSub });
    try {
        // 1. Check temp registration first (using auth_provider_id)
        const registration = await prisma.temp_therapist_registrations.findFirst({
            where: {
                OR: [
                    { auth_provider_id: cognitoSub, auth_provider_type: 'cognito' },
                    { firebase_uid: cognitoSub } // Legacy compatibility
                ]
            }
        });
        if (!registration) {
            // Check if user exists in users table
            const user = await prisma.users.findFirst({
                where: {
                    OR: [
                        { auth_provider_id: cognitoSub, auth_provider_type: 'cognito' },
                        { firebase_uid: cognitoSub } // Legacy compatibility
                    ]
                }
            });
            if (user) {
                monitor.end(true, { userId: Number(user.id), status: 'approved' });
                return (0, response_1.successResponse)({
                    success: true,
                    status: 'approved',
                    user: {
                        ...user,
                        id: Number(user.id)
                    },
                    can_login: true,
                    message: 'Account is active'
                }, 'Status retrieved', requestId);
            }
            monitor.end(false);
            return (0, response_1.errorResponse)(404, 'Registration not found', requestId);
        }
        // 2. Map status to frontend expected format
        monitor.end(true, { registrationId: Number(registration.id), status: registration.registration_status });
        return (0, response_1.successResponse)({
            success: true,
            status: registration.registration_status || 'pending',
            registration: {
                id: Number(registration.id),
                status: registration.registration_status,
                workflow_stage: registration.workflow_stage,
                background_check_status: registration.background_check_status,
                can_login: registration.registration_status === 'approved',
                message: registration.deletion_reason || 'Application under review'
            },
            can_login: registration.registration_status === 'approved',
            message: registration.deletion_reason || 'Verification in progress'
        }, 'Status retrieved', requestId);
    }
    catch (error) {
        logger.error('Get therapist status error', logContext, error);
        monitor.end(false);
        return (0, response_1.errorResponse)(500, 'Failed to get status', requestId);
    }
}
//# sourceMappingURL=handler.js.map