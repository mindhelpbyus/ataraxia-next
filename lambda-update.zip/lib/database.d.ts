/**
 * Simple Database Connection for Lambda
 * Lightweight alternative to Prisma for Lambda functions
 */
import { Pool } from 'pg';
export declare function getDatabase(): Pool;
export declare function query(text: string, params?: any[]): Promise<any>;
export declare function queryOne(text: string, params?: any[]): Promise<any>;
export declare function disconnect(): Promise<void>;
//# sourceMappingURL=database.d.ts.map