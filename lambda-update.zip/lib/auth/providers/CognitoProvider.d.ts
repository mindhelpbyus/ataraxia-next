import { AuthProvider, AuthResponse, AuthUser } from '../AuthProvider';
export declare class CognitoProvider implements AuthProvider {
    private client;
    private verifier;
    private clientId;
    private userPoolId;
    constructor(region: string, userPoolId: string, clientId: string);
    signUp(email: string, password: string, attributes: {
        firstName: string;
        lastName: string;
        role: string;
        phoneNumber?: string;
        countryCode?: string;
    }): Promise<string>;
    signIn(email: string, password: string): Promise<AuthResponse>;
    confirmSignUp(email: string, code: string): Promise<boolean>;
    resendConfirmationCode(email: string): Promise<boolean>;
    forgotPassword(email: string): Promise<boolean>;
    confirmForgotPassword(email: string, code: string, newPassword: string): Promise<boolean>;
    verifyToken(token: string): Promise<AuthUser>;
    refreshToken(refreshToken: string): Promise<AuthResponse>;
}
//# sourceMappingURL=CognitoProvider.d.ts.map