import { AuthProvider, AuthResponse, AuthUser } from '../AuthProvider';
export declare class FirebaseProvider implements AuthProvider {
    private auth;
    private app;
    constructor(projectId: string, clientEmail?: string, privateKey?: string);
    signUp(email: string, password: string, attributes: {
        firstName: string;
        lastName: string;
        role: string;
        phoneNumber?: string;
        countryCode?: string;
    }): Promise<string>;
    signIn(email: string, password: string): Promise<AuthResponse>;
    verifyToken(token: string): Promise<AuthUser>;
    confirmSignUp(email: string, code: string): Promise<boolean>;
    resendConfirmationCode(email: string): Promise<boolean>;
    forgotPassword(email: string): Promise<boolean>;
    confirmForgotPassword(email: string, code: string, newPassword: string): Promise<boolean>;
    refreshToken(refreshToken: string): Promise<AuthResponse>;
}
//# sourceMappingURL=FirebaseProvider.d.ts.map